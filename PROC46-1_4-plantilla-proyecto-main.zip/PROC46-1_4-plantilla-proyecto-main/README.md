# PROC46-1_4-plantilla-proyecto
Atrapa frutas. Etapa 3. Generación de obstáculos.
Modificación por parte del alumno en tres secciones diferentes. 
Firebase activo.

### Nombre en Inglés: project-template-fruit-catcher-3